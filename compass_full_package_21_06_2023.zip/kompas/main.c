﻿#include "compass.h"

int main(void)
{

    run_program();

    return 0;
}
